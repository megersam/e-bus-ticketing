<?php
  include 'header.php';
  include '../user/connection.php';
  include '../user/session.php';

$query = "SELECT id FROM routes ORDER BY id DESC";

$result = mysqli_query($link,$query);
$row = mysqli_fetch_array($result);
$lastid = $row['id'];
if(empty($lastid))
{
    $number = "siinaf-0001";
}
else
{
    $idd = str_replace("siinaf-", "", $lastid);
    $id = str_pad($idd + 1, 4, 0, STR_PAD_LEFT);
    $number = 'siinaf-'.$id;
}
 ?>

<div id="content">
    <div id="content-header">
        <div id="breadcrumb"><a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i>
            Add New Route</a></div>
    </div> 
    <div class="container-fluid">

        <div class="row-fluid" style="background-color: white; min-height: 1000px; padding:10px;">
        <div class="row-fluid">
    <div class="span12">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>New Route</h5>
        </div>

   


        <div class="widget-content nopadding">
          <form name = "form1" action="" method="post" class="form-vertical">


          <div class="span2">
              <label>Date :</label>
              <div>
                <input type="text" class="span11" name="date"  required  value="<?php echo date("Y-m-d") ?>"
                                               readonly/>
              </div>
            </div>
         
            <!-- <div class="span2">
              <label>Initial City :</label>
              <div>
                <input type="text" class="span11" placeholder="intial Place" name="icity"  required/>
              </div>
            </div> -->

            <div class="span2">
                            <div>
                                <label>Initial Place</label>
                                <select class="span11" name="icity" id="icity">
                      <option>Select</option>
                       <?php
                       $res=mysqli_query($link, "SELECT * FROM place");
                       while($row=mysqli_fetch_array($res))
                       {
                           echo "<option>";
                           echo $row["place"];
                           echo "</option>";
                       }
                       ?>
                       </select>
                            </div>
                        </div>


            <!-- <div class="span2">
              <label>Destination City :</label>
              <div>
                <input type="text" class="span11" placeholder="Final Place" name="dcity" required/>
              </div>
            </div> -->
            <div class="span2">
                            <div>
                                <label>Destination Place</label>
                                <select class="span11" name="dcity" id="dcity">
                      <option>Select</option>
                       <?php
                       $res=mysqli_query($link, "SELECT * FROM place");
                       while($row=mysqli_fetch_array($res))
                       {
                           echo "<option>";
                           echo $row["place"];
                           echo "</option>";
                       }
                       ?>
                       </select>
                            </div>
                        </div>


            <div class="span2">
              <label>Date :</label>
              <div>
                <input type="date" class="span11" placeholder="Date" name="date" required/>
              </div>
            </div>


            <div class="span2">
              <label>Time :</label>
              <div>
                <input type="ratio" step= 0.01 class="span11"  name="time" required/>
              </div>
            </div>

             

            <div class="span2">
              <label>Seats:</label>
              <div>
                <input type="number" class="span11" placeholder="total seats per bus" name="seats" required/>
              </div>
            </div>


            <div class="span2">
              <label>Price :</label>
              <div>
                <input type="decimal" class="span11" placeholder="price" name="price" required/>
              </div>
            </div>

        
            <div class="span2">
              <label>Bus ID :</label>
              <div>
                <input type="text" class="span11" placeholder="Buss ID" name="busid" required/>
              </div>
            </div>


            <div class="span2">
              <label>User Name</label>
              <div>
                <input type="text"  class="span11" placeholder="username" name="uname" readonly
                value="<?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?>"/>
              </div>
            </div>
            <div class="span2">
              <label>Route ID</label>
              <div>
                <input type="text"  class="span11" placeholder="idlabel" name="idlabel" 
                readonly value="<?php echo $number; ?>"/>
              </div>
            </div>
             

            
          

<!-- <div>
<div class="widget-content nopadding">
            <div class="form-actions">
              <button type="submit" name="submit1" class="btn btn-success">Save</button>
            </div>
</div>
</div> -->
<div class="span2">
<label></label>
  <div>
    <button type="submit" name="submit1" class="btn btn-success"> Save</button>
</div>
</div>

<div class="span2">
<label></label>
  <div>
    <button type="submit" name="submit2" class="btn btn-success"> Search</button>
</div>
</div>
            
<div class="alert alert-success" id="success" style="display:none">
                Record Inserted Successfully !
</div>
<div class="alert alert-error" id="error1" style="display:none">
                 initial and destination city can't be same !
</div>
<div class="alert alert-error" id="error" style="display:none">
                same data already existed try again !
</div>
          </form>
       
        </div>
      </div>



                      </div>
                   
                      
                      <div class="span11">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>View Routes</h5>
        </div>
                      
      <div class="widget-content nopadding">
            <table class="table table-bordered table-striped" name ="table">
              <thead>
                <tr>
                <th>Id</th>
                  <th>Inital City</th>
                  <th>Destination City</th>
                  <th>Date</th>
                  <th>Initial Time</th>
                  <th>Price</th>
                  <th>Seats</th>
                  <th>Status</th>
                  <th>Buss ID</th>
                  <th>Edit</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody>
                <?php
                   $res = mysqli_query($link, "select * from Routes");
                   while($row=mysqli_fetch_array($res))
                   {
                     ?> 
                      <tr>
                      <td><?php echo $row["id"]; ?></td>
                  <td><?php echo $row["Initial"]; ?></td>
                  <td><?php echo $row["Final"]; ?></td>
                  <td><?php echo $row["Date"]; ?></td>
                  <td><?php echo $row["Time"]; ?></td>
                  <td><?php echo $row["Price"]; ?></td>
                  <td><?php echo $row["Seats"]; ?></td>
                  <td><?php echo $row["status"]; ?></td> 
                  <td><?php echo $row["BusNo"]; ?></td>
                  <td><center><a href="editRoute.php?id=<?php echo $row["id"]; ?>" style="color:blue">Edit</a></center></td>
                  <td><center><a href="deleteRoute.php?id=<?php echo $row["id"]; ?>"style="color:red">Delete</a></center></td>
                  </tr>
                     <?php
                   }
                ?>
               
              </tbody>
            </table>
          </div>
                  </div>
                  </div>
     </div>
    </div>
   </div>
</div>
      <?php
       if(isset($_POST["submit1"]))
      {
         
          $count =0;
          $res=mysqli_query($link, "select * from Routes where Initial='$_POST[icity]' && Final='$_POST[dcity]' && Date='$_POST[date]' && Time='$_POST[time]' && Seats='$_POST[seats]' && Price='$_POST[price]' && BusNo='$_POST[busid]' && Status='Active' && UserName='$_POST[uname]'");
          $count = mysqli_num_rows($res);
          if($count>0)
          {
            ?>
              <script type="text/javascript">
                  setTimeout(function(){
                  window.location.href=window.location.href;
                },3000);
                document.getElementById("success").style.display="none";
                document.getElementById("error").style.display="block";
                </script>
                <?php
          }
          
          
          else
          {
              mysqli_query($link,"insert into Routes values('$_POST[idlabel]','$_POST[icity]','$_POST[dcity]','$_POST[time]','$_POST[date]','$_POST[seats]','$_POST[price]','$_POST[busid]','Active','$_POST[uname]')");
              ?>
              <script type="text/javascript">
                   setTimeout(function(){
                  window.location.href=window.location.href;
                },3000);
                document.getElementById("error").style.display="none";
                document.getElementById("success").style.display="block";
                </script>
                <?php
          }
         
      } 
      ?>


          
<?php
include "footer.php"
?>