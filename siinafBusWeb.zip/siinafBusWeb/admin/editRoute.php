<?php
  include 'header.php';
  include "../user/connection.php";
  include "../user/session.php";
  $id=$_GET["id"];
  $initial="";
  $final="";
  $date="";
  $time="";
  $seats="";
  $price="";
  $busno="";
  $status="";
  $username="";
  $res=mysqli_query($link, "select * from routes where id='$id'");
  while($row=mysqli_fetch_array($res))
  {
      $initial=$row["Initial"];
      $final=$row["Final"];
      $lastname=$row["LastName"];
      $date=$row["Date"];
      $time=$row["Time"];
      $seats=$row["Seats"];
      $price=$row["Price"];
      $busno=$row["BusNo"];
      $status=$row["status"];
      $username = $row["UserName"];
  }
 ?>

<div id="content">
    <div id="content-header">
        <div id="breadcrumb"><a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i>
            Home</a></div>
    </div> 
    <div class="container-fluid">

        <div class="row-fluid" style="background-color: white; min-height: 1000px; padding:10px;">
          Edit Routes
            <div class="span12">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>Edit Routes</h5>
        </div>


        <div class="widget-content nopadding">
          <form name = "form1" action="" method="post" class="form-horizontal">
            <div class="control-group">
              <label class="control-label">Initial Place:</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="Initial place" name="icity"  required value="<?php echo $initial; ?>"/>
              </div>
            </div>


            <div class="control-group">
              <label class="control-label">Final Place :</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="Final Place" name="fcity" required value="<?php echo $final; ?>"/>
              </div>
            </div>

            <div class="control-group">
              <label class="control-label">Date :</label>
              <div class="controls">
                <input type="date" class="span11" placeholder="date" name="date" required value="<?php echo $date; ?>"/>
              </div>
            </div>

            
            <div class="control-group">
              <label class="control-label">Time :</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="time" name="time" required value="<?php echo $time; ?>"/>
              </div>
            </div>

            <div class="control-group">
              <label class="control-label">Seats :</label>
              <div class="controls">
                <input type="text" name="seats" class="span11" placeholder="seats" required value="<?php echo $seats; ?>"/>
              </div>
            </div>
 

            <div class="control-group">
              <label class="control-label">price :</label>
              <div class="controls">
                <input type="decimmal" class="span11" name="price" required value="<?php echo $price; ?>"/>
              </div>
            </div>


            <div class="control-group">
              <label class="control-label">Buss No :</label>
              <div class="controls">
                <input type="text" class="span11" name="bussno" required value="<?php echo $busno; ?>"/>
              </div>
            </div>

        <div class="control-group">
              <label class="control-label">User Name:</label>
              <div class="controls">
                <input type="text" class="span11"  required readonly name="uname"
                value="<?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?>"/>
              </div>
            </div>
                 
            <div class="control=group">
                <label class="control-label"> Status</label>
                <div class="controls">
                    <select name="status" class="span11">
                        <option <?php if($status=="Active") {echo "selected";} ?>>Active </option>
                        <option <?php if($status=="Innactive") {echo "selected";}?>>Innactive </option>
</select>
</div>
</div>
  

<div class="form-actions">
              <button type="submit" name="submit1" class="btn btn-success">Update</button>
            </div>
            <div class="alert alert-success" id="success" style="display:none">
                Record Updated Successfully !
</div>
</div>
        </div>
    </div>
</div>
</div>
<?php
 if(isset($_POST["submit1"]))
 {
     mysqli_query($link, "update routes set Initial='$_POST[icity]',Final='$_POST[fcity]',Date='$_POST[date]', Time='$_POST[time]',Price='$_POST[price]', Seats='$_POST[seats]',BusNo='$_POST[bussno]',UserName='$_POST[uname]',Status='$_POST[status]' where id='$id'") or die(myqsli_error($link));
     ?>
     <script type="text/javascript">
          setTimeout(function(){
              window.location="add_Routes.php";
          },3000);
         document.getElementById("success").style.display = "block";
         </script>
     <?php   
 }
?>
<?php
include "footer.php"
?>