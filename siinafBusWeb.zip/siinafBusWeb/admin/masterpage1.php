<?php
  include 'header.php';
  include '../user/connection.php';
  include '../user/session.php';
  $qnty="1";
  $query = "SELECT id FROM sales ORDER BY id DESC";

$result = mysqli_query($link,$query);
$row = mysqli_fetch_array($result);
$lastid = $row['id'];
if(empty($lastid))
{
    $number = "siinafticket-0001";
}
else
{
    $idd = str_replace("siinafticket-", "", $lastid);
    $id = str_pad($idd + 1, 4, 0, STR_PAD_LEFT);
    $number = 'siinafticket-'.$id;
}
  $id=$_GET["id"];
  $initialPlace="";
  $finalPlace="";
  $travelDate="";
  $timeInitial="";
  $seats="";
  $price="";
  $busId="";
  $routeId="";

  $res=mysqli_query($link, "SELECT * FROM routes WHERE id='$id'");
  while($row=mysqli_fetch_array($res))
  {
      $initialPlace=$row["Initial"];
      $finalPlace=$row["Final"];
      $travelDate=$row["Date"];
      $timeInitial=$row["Time"];
      $seats=$row["Seats"];
      $price=$row["Price"];
      $busId=$row["BusNo"];
      $routeId=$row["id"]; 
      $username = $row["UserName"];
      $status = $row["status"];
  }
 
 ?>

<div id="content">
    <div id="content-header">
        <div id="breadcrumb"><a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i>
            Ticket registration</a></div>
    </div> 
    <div class="container-fluid">

        <div class="row-fluid" style="background-color: white; min-height: 1000px; padding:10px;">
        <div class="row-fluid">
    <div class="span12">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>Ticket registration</h5>
        </div>

   


        <div class="widget-content nopadding">
          <form name = "form1" action="" method="post" class="form-vertical">


          <div class="span2">
              <label>Today:</label>
              <div>
                <input type="text" class="span11" name="today"  required  value="<?php echo date("Y-m-d") ?>"
                                               readonly/>
              </div>
            </div>

            <div class="span2">
              <label>Ticket No:</label>
              <div>
                <input type="text" class="span11" name="ticketno"  required  value="<?php echo $number; ?>"
                                               readonly/>
              </div>
            </div>
          

            <div class="span2">
              <label>Initial Place :</label>
              <div>
                <input type="text" class="span11" name="intialPlace"  required placeholder="Initial Place"
                value="<?php echo $initialPlace; ?>"readonly/>
              </div>
            </div>




            <div class="span2">
              <label>Destination Place :</label>
              <div>
                <input type="text" class="span11" name="finalPlace"  required placeholder="Destination city"
                value="<?php echo $finalPlace; ?>"readonly/>
              </div>
            </div>

             


            <div class="span2">
              <label> Travel Date :</label>
              <div>
                <input type="date" class="span11" placeholder="travel date" name="traveldate" required
                value="<?php echo $travelDate; ?>" readonly/>
              </div>
            </div>


            <div class="span2">
              <label>Time :</label>
              <div>
                <input type="ratio" step= 0.01 class="span11"  name="time" required 
                value="<?php echo $timeInitial; ?>"readonly/>
              </div>
            </div>

             

            <div class="span2">
              <label> Available Seats:</label>
              <div>
                <input type="number" class="span11" placeholder="total seats per bus" name="seats" required 
                value="<?php echo $seats; ?>"readonly/>
              </div>
            </div>


            <div class="span2">
              <label>Price :</label>
              <div>
                <input type="decimal" class="span11" placeholder="price" name="price" required 
                value="<?php echo $price; ?>" readonly/>
              </div>
            </div>

        
            <div class="span2">
              <label>Bus ID :</label>
              <div>
                <input type="text" class="span11" placeholder="Buss ID" name="busid" required 
                value="<?php echo $busId; ?>"readonly/>
              </div>
            </div>


            <div class="span2">
              <label>User Name</label>
              <div>
                <input type="text"  class="span11" placeholder="username" name="uname" readonly
                value="<?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?>"/>
              </div>
            </div>


            <div class="span2">
              <label>Route ID</label>
              <div>
                <input type="text"  class="span11" name="routeid" 
                readonly  placeholder="travel id"
                value="<?php echo $routeId; ?>"/>
              </div>
            </div>

            <div class="span2">
              <label>qnty</label>
              <div>
                <input type="text"  class="span11" name="qntyy" 
                readonly  placeholder="travel id"
                value="<?php echo $qnty; ?>"/>
              </div>
            </div>

              
            <div class="span4">
              <label>Full Name</label>
              <div>
                <input type="text"  class="span11" placeholder="full name" name="fullname" 
                />
              </div>
            </div>
             
            <div class="span4">
              <label>Phone no</label>
              <div>
                <input type="number"  class="span11" placeholder="phone no" name="phone" 
                />
              </div>
            </div>

            
          
 
<div class="span2">
<label></label>
  <div>
    <button type="submit" name="submit1" class="btn btn-success"> Save</button>
</div>
</div>

 
            
<div class="alert alert-success" id="success" style="display:none">
                Record Inserted Successfully !
</div>
<div class="alert alert-error" id="error1" style="display:none">
                 initial and destination city can't be same !
</div>
<div class="alert alert-error" id="error" style="display:none">
                same data already existed try again !
</div>
          </form>

          <div class="span11">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5><center> check bills </center></h5>
        </div>
        <div class="widget-content nopadding">
            <table class="table table-bordered" name ="table">
              <thead>
                <tr>
                <th>Ticket Id</th>
                  <th>Inital City</th>
                  <th>Destination City</th>
                  <th>Date</th>
                  <th>Full Name</th>
                  <th>Phone</th>
                  <th>Viw Detail</th>
                 
                  <th>Resend code</th>
                
                </tr>
              </thead>
              <tbody>
              <?php
                   $res = mysqli_query($link, "select * from sales order by id desc");
                   while($row=mysqli_fetch_array($res))
                   {
                     ?> 
                      <tr>
                  <td><?php echo $row["id"]; ?></td>
                  <td><?php echo $row["Initial"]; ?></td>
                  <td><?php echo $row["Final"]; ?></td>
                  <td><?php echo $row["Date"]; ?></td>
                  <td><?php echo $row["FullName"]; ?></td>
                  <td><?php echo $row["Phone"]; ?></td>
                  <td><center><a href="detailsBill.php?id=<?php echo $row["id"]; ?>"style="color:white" class="btn btn-success">View Detail</a></center></td>
 
                  <td><center><a href="masterpage1.php?id=<?php echo $row["id"]; ?>"style="color:blue" class="btn btn-success">Re send</a></center></td>
                  </tr>
                     <?php
                   }
                ?>
              </tbody>
            </table>
          </div>
          </div>
                  </div>
                  </div>
       
        </div>
      </div>



                      </div>
 
     </div>
    </div>
   </div>
</div>
      

<?php
       if(isset($_POST["submit1"]))
      {
          
              mysqli_query($link,"INSERT INTO sales VALUES('$_POST[ticketno]','$_POST[routeid]','$_POST[fullname]','$_POST[phone]','$_POST[intialPlace]','$_POST[finalPlace]','$_POST[time]','$_POST[traveldate]','$_POST[price]','$_POST[busid]','Active','$_POST[uname]','$_POST[today]')")or die(myqsli_error($link));
              mysqli_query($link, "UPDATE routes SET Seats= Seats-1 WHERE id='$id'")or die(myqsli_error($link));
              ?>
              <script type="text/javascript">
                   setTimeout(function(){
                    window.location="masterpage1.php";
                },1000);
                document.getElementById("error").style.display="none";
                document.getElementById("success").style.display="block";
                </script>
                <?php
          }
         
      
      ?>    
<?php
include "footer.php"
?>