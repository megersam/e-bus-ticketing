<?php
include "header.php";
include "../user/connection.php";
include "../user/session.php"; 
 
?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <div id="content">
        <!--breadcrumbs-->
        <div id="content-header">
            <div id="breadcrumb"><a href="index.html" class="tip-bottom"><i class="icon-home"></i>
                    My Profile</a></div>
        </div>

        <div class="container-fluid">
            <form name="form1" action="" method="post" class="form-horizontal nopadding">
                <div class="row-fluid" style="background-color: white; min-height: 100px; padding:10px;">
                    <div class="span12">
                        <div class="widget-box">
                            <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                                <h5>My Profile</h5>
                            </div>

                            <div class="widget-content nopadding">

                           


                                <div class=" span2">
                                <div class= "row-col-lg-3">
                                <img src="../admin/img/default-user-avatar.png" class="img img-rounded" width="200">
                            </div>
                                    <br>

                                    <div>
                                        <label>User Name</label>
                                        <input type="text" class="span12" name="uname" readonly 
                                        value="<?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?>">
                                    </div>
                                </div>

                                <div class="span2">
                                    <br>

                                    <div>
                                <label>First Name</label>
                                <input type="text" class="span11" name="first name" id="fname" value="<?php echo $firstname; ?>">
                            </div>
                                </div>

                                <div class="span2">
                                    <br>

                                    <div>
                                        <label>Middle Name</label>
                                        <input type="text" class="span11" name="mname"
                                               value="<?php echo date("Y-m-d") ?>"
                                               >
                                    </div>
                                </div>
                                <div class="span2">
                                    <br>

                                    <div>
                                        <label>Last Name</label>
                                        <input type="text" class="span11" name="lname"
                                               value="<?php echo date("Y-m-d") ?>"
                                               >
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>

                <!-- new row-->
                <div class="row-fluid" style="background-color: white; min-height: 100px; padding:10px;">
                    <div class="span12">


                        <center><h4>Select A Product</h4></center>


                        <div class="span2">
                            <div>
                                <label>Product Company</label>
                                <select class="span11" name="companyname" id="companyname" onchange="selectcompany(this.value)">
                      <option>Select</option>
                       <?php
                       $res=mysqli_query($link, "select * from company");
                       while($row=mysqli_fetch_array($res))
                       {
                           echo "<option>";
                           echo $row["companyname"];
                           echo "</option>";
                       }
                       ?>
                       </select>
                            </div>
                        </div>

                        <div class="span2">
                            <div>
                                <label>Product Name</label>
                                <div id="productname">
                                    <select class="span11">
                                        <option>Select</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="span1">
                            <div>
                                <label>Unit</label>
                                <div id="unit">
                                    <select class="span11">
                                        <option>Select</option>
                                    </select>
                                </div>

                            </div>
                        </div>

                        <div class="span2">
                            <div>
                                <label>Packing Size</label>
                                <div id="packingsize">
                                    <select class="span11">
                                        <option>Select</option>
                                    </select>
                                </div>
                            </div>
                        </div>


                        <div class="span1">
                            <div>
                                <label>Price</label>
                                <input type="text" class="span11" name="price" id="price" readonly  value="o">
                            </div>
                        </div>

                        <div class="span1">
                            <div>
                                <label>Enter Qty</label>
                                <input type="text" class="span11" name="qty" id="qty" autocomplete="off">
                            </div>
                        </div>



                        <div class="span1">
                            <div>
                                <label>Total</label>
                                <input type="text" class="span11" name="total" id="total" value="0" readonly>
                            </div>
                        </div>

                        <div class="span1">
                            <div>
                                <label>&nbsp</label>
                                <input type="button" class="span11 btn btn-success" value="Add">
                            </div>
                        </div>

                    </div>
                </div>

                <!-- end new row-->


            </form>



 
        </div>
    </div>


 




<?php
include "footer.php";
?>