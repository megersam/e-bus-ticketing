<?php
  include 'header.php';
  include '../user/connection.php';
 ?>

<div id="content">
    <div id="content-header">
        <div id="breadcrumb"><a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i>
            Stock Master</a></div>
    </div> 
    <div class="container-fluid">

        <div class="row-fluid" style="background-color: white; min-height: 1000px; padding:10px;">
        <div class="row-fluid">
      <div class="widget-content nopadding">
            <table class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>Sr No</th>
                  <th>Product company</th>
                  <th>product Name</th>
                  <th>Unit</th>
                  <th>Qnty</th>
                  <th>Price Sell</th>
                  <th>Edit</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $count=0;
                   $res = mysqli_query($link, "select * from stockmaster");
                   while($row=mysqli_fetch_array($res))
                   {
                       $count=$count+1;
                     ?> 
                      <tr>
                  <td><?php echo $count; ?></td>
                  <td><?php echo $row["productcompany"]; ?></td>
                  <td><?php echo $row["productname"]; ?></td>
                  <td><?php echo $row["productunit"]; ?></td>
                  <td><?php echo $row["productqty"]; ?></td>
                  <td><?php echo $row["productsellingprice"]; ?></td>
                  <td><center><a href="editstockmaster.php?id=<?php echo $row["id"]; ?>" style="color:blue">Edit</a></center></td>
                  <td><center><a href="delete_products.php?id=<?php echo $row["id"]; ?>"style="color:red">Delete</a></center></td>
                  </tr>
                     <?php
                   }
                ?>
               
              </tbody>
            </table>
          </div>
</div>
</div>
</div>
</div>
          
<?php
include "footer.php"
?>