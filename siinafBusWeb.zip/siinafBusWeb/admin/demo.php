 <?php
  include 'header.php';
  include '../user/session.php';
 ?>

<div id="content">
    <div id="content-header">
        <div id="breadcrumb"><a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i>
            Home</a></div>
    </div> 
    <div class="container-fluid">

        <div class="row-fluid" style="background-color: white; min-height: 1000px; padding:10px;">
         <p>You are Logged in as <?php if(isset($_SESSION['username'])) echo $_SESSION['username']; ?></p>
         <p>You are Logged in ID <?php if(isset($_SESSION['id'])) echo $_SESSION['id']; ?></p>
        </div>

    </div>
</div>
<?php
include "footer.php"
?>