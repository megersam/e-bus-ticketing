<?php
include "header.php";
include "../user/connection.php";
  $price = "";
?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <div id="content">
        <!--breadcrumbs-->
        <div id="content-header">
            <div id="breadcrumb"><a href="index.html" class="tip-bottom"><i class="icon-home"></i>
                    Ticket Seles</a></div>
        </div>

        <div class="container-fluid">
            <form name="form1" action="" method="post" class="form-horizontal nopadding">
                <div class="row-fluid" style="background-color: white; min-height: 100px; padding:10px;">
                    <div class="span12">
                        <div class="widget-box">
                            <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                                <h5>Ticket Seles</h5>
                            </div>


                    </div>
                </div>

                <!-- new row-->
                <div class="row-fluid" style="background-color: white; min-height: 100px; padding:10px;">
                    <div class="span12">


                        <div class="span2">
                            <div>
                                <label>initial City</label>
                                <select class="span11" name="companyname" id="companyname" onchange="selectcompany(this.value)">
                      <option>Select</option>
                       <?php
                       $res=mysqli_query($link, "select * from Routes");
                       while($row=mysqli_fetch_array($res))
                       {
                           echo "<option>";
                           echo $row["Initial"];
                           echo "</option>";
                       }
                       ?>
                       </select>
                            </div>
                        </div>

                        <div class="span2">
                            <div>
                                <label>Destination City</label>
                        
                                <div id="productname">
                                    <select class="span11">
                                        <option>Select</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="span2">
                            <div>
                                <label>Date</label>
                                <div id="date">
                                <input type="date" class="span11" placeholder="Date" name="date" required/>
                                </div>

                            </div>
                        </div>
                        

                        <div class="span2">
                            <div>
                                <label>Time </label>
                                <div id="packingsize">
                                    <select class="span11">
                                        <option>Select</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="span2">
<label></label>
  <div>
    <button type="submit" name="submit1" class="btn btn-success"> Search</button>
</div>
</div>

                        
 
 
                        </div>

                    <!-- </div>
                </div> -->

                <!-- end new row-->


            </form>

    
             

                   
            <div class="span11">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5><center> Search Result </center></h5>
        </div>
                      
      <div class="widget-content nopadding">
            <table class="table table-bordered table-striped" name ="table">
              <thead>
                <tr>
                <th>Id</th>
                  <th>Inital City</th>
                  <th>Destination City</th>
                  <th>Date</th>
                  <th>Initial Time</th>
                  <th>Price</th>
                  <th>Available Seats</th>
                  <th>Status</th>
                  <th>Buss ID</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                   if (isset($_POST['submit1']))
                   {
                       
                       
                       $res=mysqli_query($link, "select * from routes where Initial='$_POST[companyname]' && Final='$_POST[productname]' && Date='$_POST[date]'");
                       $count=mysqli_num_rows($res);
                       
                       if($row=mysqli_fetch_assoc($res))
                       {?>
                           <tr>
                           <td><?php echo $row['id']?></td>
                           <td><?php echo $row['Initial']?></td>
                           <td><?php echo $row['Final']?></td>
                           <td><?php echo $row['Date']?></td>
                           <td><center><?php echo $row['Time']?></center></td>
                           <td><center><?php echo $row['Price']?></center></td>
                           <td style="color:red"><center><?php echo $row['Seats']?></center></td>
                           <td><center><?php echo $row['status']?></center></td>
                           <td><center><?php echo $row['BusNo']?></center></td>
                           <td><center><a href="masterpage1.php?id=<?php echo $row["id"]; ?>"style="color:white" class="btn btn-success">Select</a></center></td>
                           </tr>
                           <?php
                       }
                       else
                       {
                           ?>
                           <tr>
                           <td colspan="10" style="color:red"> <center>No Record Found on this Day please try again </center> </td>
                       </tr>
                           <?php
                       }
                   }
                ?>
               
              </tbody>
            </table>
          </div>
                  </div>
                  </div>
                  </div>
    </div>
   </div>
</div>   
                


<script type = "text/javascript">
 function selectcompany(companyname)
    {
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function (){
        if(xmlhttp.readyState == 4 && xmlhttp.status ==200){
          document.getElementById("productname").innerHTML=xmlhttp.responseText;
        }
      };
      xmlhttp.open("GET", "forajax/loadplaces.php?companyname="+companyname, true);
      xmlhttp.send();
    }
    function selectproduct(productname,companyname)
    {
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function (){
        if(xmlhttp.readyState == 4 && xmlhttp.status ==200){
          document.getElementById("unit").innerHTML=xmlhttp.responseText;
        }
      };
      xmlhttp.open("GET", "forajax/load_unit_using_product.php?productname="+productname+ "&companyname="+companyname, true);
      xmlhttp.send();
    }
    function selectunit(unit, productname, companyname)
    {
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function (){
        if(xmlhttp.readyState == 4 && xmlhttp.status ==200){
          document.getElementById("packingsize").innerHTML=xmlhttp.responseText;
          $('#packingsize').on('change', function(){
            loadprice(document.getElementById("packingsize").value);
          });
        }
      };
      xmlhttp.open("GET", "forajax/load_packingsize_using_product.php?unit="+unit+"&productname="+productname+"&companyname="+companyname, true);
      xmlhttp.send();
    }
    function loadprice(packingsize){
    var companyname = document.getElementById("companyname").value;
    var productname = document.getElementById("productname").value;
    var unit = document.getElementById("unit").value;

    var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function (){
        if(xmlhttp.readyState == 4 && xmlhttp.status ==200){
            // alert(xmlhttp.responseText);
             document.getElementById("Price").value = xmlhttp.responseText;
        }
      };
      xmlhttp.open("GET", "forajax/loadprice.php?companyname="+companyname+"&productname="+productname+"&unit="+unit+"&packingsize="+packingsize, true);
      xmlhttp.send();
}
</script>
<?php
include "footer.php";
?>