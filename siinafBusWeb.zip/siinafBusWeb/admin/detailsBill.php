<link rel="stylesheet" type="text/css" href="print.css" media="print">
<?php

  include 'header.php';
  include '../user/session.php';
  include '../user/connection.php';

  $id=$_GET["id"];
  $dateRegistered="";
  $invoiceno="";
  $routeid="";
  $fullName="";
  $phone="";
  $initial="";
  $final="";
  $time="";
  $date="";
  $price="";
  $busno="";
  $status="";
  $username="";

  $res=mysqli_query($link, "SELECT * FROM sales WHERE id='$id'")or die(myqsli_error($link));
  while($row=mysqli_fetch_array($res))
  {
      $invoiceno=$row["id"];
      $routeid=$row["routeid"];
      $fullName=$row["FullName"];
      $phone=$row["Phone"];
      $initial=$row["Initial"];
      $final=$row["Final"];
      $time=$row["Time"];
      $date=$row["Date"];
      $price=$row["Price"];
      $busno=$row["BusNo"];
      $status=$row["Status"];
      $username=$row["Username"];
      $dateRegistered=$row["today"];
  }
 ?>
 <style>
     @media print{
         body * {
             visibility: hidden;
         }
         .print-container, .print-container *{
             visibility: visible;
         }
     }
     </style>

<div id="content" >
    <div id="content-header" >
        <div id="breadcrumb"><a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i>
            Details Bill</a></div>
    </div> 
    <div class=" print-container">
    <div class="container-fluid" >
  
        <div class="row-fluid" style="background-color: white; min-height: 700px; padding:10px;">
          <center> 
              <h4> Details Bill</h4>
          </center>
          <table>
              <tr>
                  <td> Date Registered:</td>
                  <td><?php echo $dateRegistered; ?></td>
             </tr>

             <tr>
                  <td> Ticket No:</td>
                  <td><?php echo $invoiceno; ?></td>
             </tr>

             <tr>
                  <td> Full Name:</td>
                  <td><?php echo $fullName; ?></td>
             </tr>

             <tr>
                  <td> Phone:</td>
                  <td><?php echo $phone; ?></td>
             </tr>

        </table>

        <br>

        <table class="table table-bordered">
            <tr>
                <th> Route id</th>
                <th> Intial</th>
                <th> Final</th>
                <th> Date</th>
                <th> Time</th>
                <th> price</th>
                <th> Sales name</th>
               
            </tr>
            <tbody>
              <?php
                   $res = mysqli_query($link, "select * from sales where id='$id'");
                   while($row=mysqli_fetch_array($res))
                   {
                     ?> 
                      <tr>
                  <td><?php echo $row["routeid"]; ?></td>
                  <td><?php echo $row["Initial"]; ?></td>
                  <td><?php echo $row["Final"]; ?></td>
                  <td><?php echo $row["Date"]; ?></td>
                  <td><?php echo $row["Time"]; ?></td>
                  <td><?php echo $row["Price"]; ?></td>
                  <td><?php echo $row["Username"]; ?></td>
                 
                  </tr>
                     <?php
                   }
                ?>
              </tbody>


        </table>
        <div class="text-center">
        <button onclick="window.print();" class="btn btn-primary" id="print-btn">Print</button>
        <button onclick="window.print();" class="btn btn-primary" id="print-btn">SMS</button>
      </div>
 
        </div>
                </div>

    </div>
</div>
<?php
include "footer.php"
?>