<?php
include "../user/connection.php";
$id=$_GET["id"];
mysqli_query($link, "DELETE FROM routes WHERE id='$id'")or die(mysqli_error($link));
?>
<script type="text/javascript">
    window.location="add_Routes.php";
    </script>