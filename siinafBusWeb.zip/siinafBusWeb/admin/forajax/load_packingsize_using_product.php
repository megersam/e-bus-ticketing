<?php
include"../../user/connection.php";
$unit=$_GET["unit"];
$companyname=$_GET["companyname"];
$productname=$_GET["productname"];
$res=mysqli_query($link, "select * from Routes where Initial='$companyname'&& Final='$productname' && Date='$unit'");
?>
 <select class="span11" name="packingsize" id="packingsize">
     <option>Select</option>

<?php

while($row=mysqli_fetch_array($res))
{
  echo "<option>";
  echo  $row["Time"];
  echo "</option>";
}
echo "</select>";
?>