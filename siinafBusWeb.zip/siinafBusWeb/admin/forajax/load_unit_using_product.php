<?php
include"../../user/connection.php";
$companyname=$_GET["companyname"];
$productname=$_GET["productname"];
$res=mysqli_query($link, "select * from Routes where Initial='$companyname'&& Final='$productname'");
?>
 <select class="span11" name="date" id="date" onchange="selectunit(this.value,'<?php echo $productname; ?>','<?php echo $companyname; ?>')">
     <option>Select</option>

<?php

while($row=mysqli_fetch_array($res))
{
  echo "<option>";
  echo  $row["Date"];
  echo "</option>";
}
echo "</select>";
?>