<?php
include "../../user/connection.php";
$companyname=$_GET["companyname"];
$productname=$_GET["productname"];
$unit=$_GET["unit"];
$packingsize=$_GET["packingsize"];

$res=mysqli_query($link, "SELECT * from Routes where  Initial='$companyname' && Final='$productname' && Date='$unit' && Time='$packingsize'") or die(mysqli_error($link));
  
?>
 <select class="span11" name="Price" id="price" onchange="selectunit(this.value,'<?php echo $companyname; ?>','<?php echo $productname; ?>','<?php echo $unit; ?>','<?php echo $packingsize; ?>')">
     <option>Select</option>

<?php
while($row=mysqli_fetch_array($res))
 {
    echo "<option>";
    echo  $row["Price"];
    echo "</option>"; 
 }
 echo "</select>";

?>

 