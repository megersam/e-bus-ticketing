<?php
include"../../user/connection.php";
$companyname=$_GET["companyname"];
$productname=$_GET["productname"];
$date=$_GET["date"];
$res=mysqli_query($link, "select * from Routes where Initial='$companyname'&& Final='$productname' && Date='$date'");
?>
 <select class="span11" name="time" id="time" onchange="selectunit(this.value,'<?php echo $productname; ?>','<?php echo $companyname; ?>','<?php echo $date; ?>')">
     <option>Select</option>

<?php

while($row=mysqli_fetch_array($res))
{
  echo "<option>";
  echo  $row["Time"];
  echo "</option>";
}
echo "</select>";
?>