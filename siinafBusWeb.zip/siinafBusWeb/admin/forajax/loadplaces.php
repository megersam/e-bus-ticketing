<?php
include"../../user/connection.php";
$companyname=$_GET["companyname"];
$res=mysqli_query($link, "select * from Routes where Initial='$companyname'");
?>
 <select class="span11" name="productname" id="productname" onchange="selectproduct(this.value, '<?php echo $companyname ?>')">
     <option>Select</option>

<?php

while($row=mysqli_fetch_array($res))
{
  echo "<option>";
  echo  $row["Final"];
  echo "</option>";
}
echo "</select>";
?>