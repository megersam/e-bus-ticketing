<?php
include "header.php";
include "../user/connection.php";
?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <div id="content">
        <!--breadcrumbs-->
        <div id="content-header">
            <div id="breadcrumb"><a href="index.html" class="tip-bottom"><i class="icon-home"></i>
                    Sale a products</a></div>
        </div>

        <div class="container-fluid">
            <form name="form1" action="" method="post" class="form-horizontal nopadding">
                <div class="row-fluid" style="background-color: white; min-height: 100px; padding:10px;">
                    <div class="span12">
                        <div class="widget-box">
                            <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                                <h5>Sale a Products</h5>
                            </div>

                          
                        </div>

                    </div>
                </div>

                <!-- new row-->
                <div class="row-fluid" style="background-color: white; min-height: 100px; padding:10px;">
                    <div class="span12">


                        <center><h4>Select A Product</h4></center>


                        <div class="span2">
                            <div>
                                <label>Product Company</label>
                                <select class="span11" name="companyname" id="companyname" onchange="selectcompany(this.value)">
                      <option>Select</option>
                       <?php
                       $res=mysqli_query($link, "select * from company");
                       while($row=mysqli_fetch_array($res))
                       {
                           echo "<option>";
                           echo $row["companyname"];
                           echo "</option>";
                       }
                       ?>
                       </select>
                            </div>
                        </div>

                        <div class="span2">
                            <div>
                                <label>Product Name</label>
                                <div id="productname">
                                    <select class="span11">
                                        <option>Select</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="span1">
                            <div>
                                <label>Unit</label>
                                <div id="unit">
                                    <select class="span11">
                                        <option>Select</option>
                                    </select>
                                </div>

                            </div>
                        </div>

                        <div class="span2">
                            <div>
                                <label>Packing Size</label>
                                <div id="packingsize">
                                    <select class="span11">
                                        <option>Select</option>
                                    </select>
                                </div>
                            </div>
                        </div>


                        <div class="span1">
                            <div>
                                <label>Price</label>
                                <input type="text" class="span11" name="price" id="price" readonly  value="o">
                            </div>
                        </div>

                        <div class="span1">
                            <div>
                                <label>Enter Qty</label>
                                <input type="text" class="span11" name="qty" id="qty" autocomplete="off">
                            </div>
                        </div>



                        <div class="span1">
                            <div>
                                <label>Total</label>
                                <input type="text" class="span11" name="total" id="total" value="0" readonly>
                            </div>
                        </div>

                        <div class="span1">
                            <div>
                                <label>&nbsp</label>
                                <input type="button" class="span11 btn btn-success" value="Add">
                            </div>
                        </div>

                    </div>
                </div>

                <!-- end new row-->


            </form>




            <div class="row-fluid" style="background-color: white; min-height: 100px; padding:10px;">
                <div class="span12">
                    <center><h4>Taken Products</h4></center>

                    <table class="table table-bordered">
                        <tr>
                            <th>Product Company</th>
                            <th>Product Name</th>
                            <th>Product Unit</th>
                            <th>Product Size</th>
                            <th>Product Price</th>
                            <th>Product Qty</th>
                            <th>Total</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                        <tr>
                            <td>Amul</td>
                            <td>Buutter</td>
                            <td>Grams</td>
                            <td>500</td>
                            <td>10</td>
                            <td>5</td>
                            <td>50</td>
                            <td style="color: green">Edit</td>
                            <td style="color:red">Delete</td>
                        </tr>
                    </table>

                    <h4>
                        <div style="float: right"><span style="float:left;">Total:&#8377;</span><span style="float: left">525</span></div>
                    </h4>


                    <br><br><br><br>

                    <center>
                        <input type="submit" value="generate bill" class="btn btn-success">
                    </center>

                </div>
            </div>
        </div>
    </div>


<script type = "text/javascript">
 function selectcompany(companyname)
    {
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function (){
        if(xmlhttp.readyState == 4 && xmlhttp.status ==200){
          document.getElementById("productname").innerHTML=xmlhttp.responseText;
        }
      };
      xmlhttp.open("GET", "forajax/load_product_using_company.php?companyname="+companyname, true);
      xmlhttp.send();
    }
    function selectproduct(productname,companyname)
    {
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function (){
        if(xmlhttp.readyState == 4 && xmlhttp.status ==200){
          document.getElementById("unit").innerHTML=xmlhttp.responseText;
        }
      };
      xmlhttp.open("GET", "forajax/load_unit_using_product.php?productname="+productname+ "&companyname="+companyname, true);
      xmlhttp.send();
    }
    function selectunit(unit, productname, companyname)
    {
      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function (){
        if(xmlhttp.readyState == 4 && xmlhttp.status ==200){
          document.getElementById("packingsize").innerHTML=xmlhttp.responseText;
          $('#packingsize').on('change', function(){
             loadprice(document.getElementById("packingsize").Value);
          });
        }
      };
      xmlhttp.open("GET", "forajax/load_packingsize_using_product.php?unit="+unit+"&productname="+productname+"&companyname="+companyname, true);
      xmlhttp.send();
    }

function loadprice(packingsize){
    var companyname = document.getElementById("companyname").Value;
    var productname = document.getElementById("productname").Value;
    var unit = document.getElementById("unit").Value;

    var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function (){
        if(xmlhttp.readyState == 4 && xmlhttp.status ==200){
             alert(xmlhttp.responseText);
             document.getElementById("price").Value = xmlhttp.responseText;
        }
      };
      xmlhttp.open("GET", "forajax/loadprice.php?companyname="+companyname+"&productname="+productname+"&unit="+unit+"&packingsize="+packingsize, true);
      xmlhttp.send();
}
</script>




<?php
include "footer.php";
?>