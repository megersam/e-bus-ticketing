<?php
  include 'header.php';
  include "../user/connection.php";
  $id=$_GET["id"];
  $firstname="";
  $middlename="";
  $lastname="";
  $sex="";
  $phone="";
  $email="";
  $username="";
  $password="";
  $position="";
  $branch="";
  $res=mysqli_query($link, "select * from Users where id=$id");
  while($row=mysqli_fetch_array($res))
  {
      $firstname=$row["FirstName"];
      $middlename=$row["MiddleName"];
      $lastname=$row["LastName"];
      $sex=$row["Sex"];
      $phone=$row["Phone"];
      $email=$row["Email"];
      $username=$row["UserName"];
      $password=$row["Password"];
      $position=$row["Position"];
      $branch=$row["Branch"];
  }
 ?>

<div id="content">
    <div id="content-header">
        <div id="breadcrumb"><a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i>
            Home</a></div>
    </div> 
    <div class="container-fluid">

        <div class="row-fluid" style="background-color: white; min-height: 1000px; padding:10px;">
            Edit user information
            <div class="span12">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>Edit User</h5>
        </div>


        <div class="widget-content nopadding">
          <form name = "form1" action="" method="post" class="form-horizontal">
            <div class="control-group">
              <label class="control-label">First Name :</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="First name" name="firstname"  required value="<?php echo $firstname; ?>"/>
              </div>
            </div>


            <div class="control-group">
              <label class="control-label">Middle Name :</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="Middle name" name="middlename" required value="<?php echo $middlename; ?>"/>
              </div>
            </div>

            <div class="control-group">
              <label class="control-label">last Name :</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="Last name" name="lastname" required value="<?php echo $lastname; ?>"/>
              </div>
            </div>

                 
            <div class="control=group">
                <label class="control-label"> Sex</label>
                <div class="controls">
                    <select name="sex" class="span11">
                        <option <?php if($sex=="Male") {echo "selected";} ?>>Male </option>
                        <option <?php if($sex=="Female") {echo "selected";}?>>Female </option>
</select>
</div>
</div>

            <div class="control-group">
              <label class="control-label">Phone:</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="Phone" name="phone" readonly required value="<?php echo $phone; ?>"/>
              </div>
            </div>

            <div class="control-group">
              <label class="control-label">Email:</label>
              <div class="controls">
                <input type="email" class="span11" placeholder="Email" name="email" required value="<?php echo $email; ?>"/>
              </div>
            </div>


            <div class="control-group">
              <label class="control-label">Username :</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="Username" name="username" readonly value="<?php echo $username; ?>"/>
              </div>
            </div>


            <div class="control-group">
              <label class="control-label">Password input</label>
              <div class="controls">
                <input type="password"  class="span11" placeholder="Password" name="password" required value="<?php echo $password; ?>"/>
              </div>
            </div>
             
            <div class="control=group">
                <label class="control-label"> Position</label>
                <div class="controls">
                    <select name="position" class="span11">
                        <option <?php if($position=="User") {echo "selected";} ?>>User </option>
                        <option <?php if($position=="Admin") {echo "selected";}?>>Admin </option>
</select>
</div>
</div>
<div class="control=group">
                <label class="control-label">Branch</label>
                <div class="controls">
                    <select name="branch" class="span11">
                        <option <?php if($branch=="Branch") {echo "selected";} ?>></option>
                        <!-- <option <?php if($status=="Inactive") {echo "selected";}?>>Inactive</option> -->
</select>
</div>
</div>
<div class="form-actions">
              <button type="submit" name="submit1" class="btn btn-success">Update</button>
            </div>
            <div class="alert alert-success" id="success" style="display:none">
                Record Updated Successfully !
</div>
</div>
        </div>
    </div>
</div>
</div>
<?php
 if(isset($_POST["submit1"]))
 {
     mysqli_query($link, "update Users set FirstName='$_POST[firstname]',MiddleName='$_POST[middlename]',LastName='$_POST[lastname]', Sex='$_POST[sex]',Phone='$_POST[phone]', Email='$_POST[email]',Password='$_POST[password]',Position='$_POST[position]',Branch='$_POST[branch]' where id=$id") or die(myqsli_error($link));
     ?>
     <script type="text/javascript">
          setTimeout(function(){
              window.location="add_new_user.php";
          },3000);
         document.getElementById("success").style.display = "block";
         </script>
     <?php   
 }
?>
<?php
include "footer.php"
?>