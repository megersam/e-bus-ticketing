<?php
  include 'header.php';
  include '../user/connection.php';
  $id=$_GET["id"];
  $companyname="";
  $productname="";
  $unit="";
  $packingsize="";
  $qnty="";
  $res=mysqli_query($link, "select * from stockmaster where id=$id");
  while($row=mysqli_fetch_array($res))
  {
      $companyname=$row["productcompany"];
      $productname=$row["productname"];
      $unit=$row["productunit"];
      $qnty=$row["productqty"];
      $pricesell=$row["productsellingprice"];
  }
 ?>

<div id="content">
    <div id="content-header">
        <div id="breadcrumb"><a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i>
            Edit Stocks Price</a></div>
    </div> 
    <div class="container-fluid">

        <div class="row-fluid" style="background-color: white; min-height: 1000px; padding:10px;">
        <div class="row-fluid">
    <div class="span12">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>Edit Stocks Price</h5>
        </div>
        <div class="widget-content nopadding">
          <form name = "form1" action="" method="post" class="form-horizontal">


          <div class="control-group">
              <label class="control-label">Product Company :</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="Product company" name="productcompany" required value="<?php echo $companyname; ?>" readonly/>
              </div>
            </div>


            <div class="control-group">
              <label class="control-label">Product Name :</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="Product name" name="productname" required value="<?php echo $productname; ?>" readonly/>
              </div>
            </div>
             

            <div class="control-group">
              <label class="control-label">Product Unit:</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="Product Unit" name="productunit" required value="<?php echo $unit; ?>" readonly/>
              </div>
            </div>

            <div class="control-group">
              <label class="control-label">Product Qnty:</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="Product qnty" name="productqnty" required value="<?php echo $qnty; ?>" readonly/>
              </div>
            </div>

            <div class="control-group">
              <label class="control-label">Product Selling Price:</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="Product selling price" name="productprice" required value="<?php echo $pricesell; ?>"/>
              </div>
            </div>



            <div class="form-actions">
              <button type="submit" name="submit1" class="btn btn-success">Update</button>
            </div>
            
<div class="alert alert-success" id="success" style="display:none">
                Record Updated Successfully !
</div>
          </form>
        </div>
      </div>
       
</div>
</div>
</div>
</div>
      <?php
       if(isset($_POST["submit1"]))
      { 
          mysqli_query($link, "update stockmaster set productsellingprice='$_POST[productprice]' where id=$id")or die(mysqli_error($link));
          ?>
        <script type="text/javascript">
             setTimeout(function(){
                 window.location="stockmaster.php";
             },3000);
            document.getElementById("success").style.display = "block";
            </script>
        <?php  
      }
      ?>
          
<?php
include "footer.php"
?>