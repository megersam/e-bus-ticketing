<?php
 include "../user/connection.php";
 $id=$_GET["id"];
 mysqli_query($link, "DELETE FROM place WHERE id=$id");
?>
<script type="text/javascript">
    window.location="add_place.php";
    </script>